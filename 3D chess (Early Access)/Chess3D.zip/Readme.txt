Duc Pham / A01054779

Piece movement : finished
Collision detection between pieces : finished
Displaying 3 chessboards at the same time: finished
Rules to moving between adjacent chessboard: finished
comments added.
methods reused
classes structure changed.

95% completed.